# Health Protector v2

School-project healthcare web prototype with:
- symptom entry and common symptom selection
- general health-information matching (not diagnosis)
- "tell more symptoms" when there is insufficient information
- live map links for nearby doctors and hospitals
- medicine reminder demo
- emergency safety guidance

The symptom feature is intentionally not presented as a medical diagnosis system. Real diagnosis requires clinical assessment and, when appropriate, testing.
